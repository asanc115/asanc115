# This PowerShell script must be run with administrative privileges
# from the same folder as the certificates.

Import-Certificate -FilePath rtnroot-G2_01.cer -CertStoreLocation 'Cert:\LocalMachine\Root' -Verbose 
Import-Certificate -FilePath rtxroot-G3_01.cer -CertStoreLocation 'Cert:\LocalMachine\Root' -Verbose 
Import-Certificate -FilePath rtngbl03.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnservices-G2_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnorion02.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnclass2-G2_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnclass3-G2_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath proxy-G2.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnusa03.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnusa04.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtncdn01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnbbn01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnhut01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtnhuu01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtxclass2-G3_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtxclass3-G3_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose
Import-Certificate -FilePath rtxservices-G3_01.cer -CertStoreLocation 'Cert:\LocalMachine\CA' -Verbose

