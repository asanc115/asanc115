#!/bin/bash

# Mozilla certificate installer for Linux
# Tested on Firefox, Thunderbird, and Seamonkey
# 
# Version 0.2 Dean DeFreitas
# Version 0.3 - 06/13/2019 - Chris Richardson - Updated script to work with later versions of Fedora and Red Hat Enterprise Linux 8.x+.


help()
{
# This help function displays usage information based on various conditions
# then exits when complete.
cat << _EOF

  $(basename $0) usage:

     $(basename $0) "Path_To_Mozilla_Directory"

  example:

    ./$(basename $0) "/home/joeuser/.mozilla/firefox/hrg0r6r27f3jd4.default/"

  NOTE: "Path_To_Mozilla_Directory" must contain the files cert8.db, key3.db, & secmod.db.

   $(basename $0) -h | --help 
         displays this help menu


_EOF

	exit
}

# Ensure that the NSS utility 'certutil' is installed on the system.
# Exit if not found
$(which certutil) 3>&1 1>&2 2>&3 | grep NSS > /dev/null 2>&1
answer=$?

if [ ${answer} -ne 0 ]; then
cat << _EOF

$(basename $0) requires the NSS utility 'certutil'.

Please install the package nss-tools >= 3.13 from the appropriate repository for your system.

_EOF
	exit
fi

# Test various conditions for required script arguments.

# User is asking for help
if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
	echo -e "\nHelp for $(basename $0)."
	help
fi

# Ensure an argument was provided.
if [ -z "$1" ]; then
	echo -e "\nError: $(basename $0) requires an argument."
	help
fi

# Ensure the argument is a valid directory.
if [ ! -d "$1" ]; then
	echo -e "\nError: Directory not Found: ${1}"
	help
fi


# Ensure the directory contains the Mozilla cert DB file cert8.db.
if [ ! -f "${1}/cert8.db" ]; then
	echo -e "\nError: File not found:  ${1}/cert8.db"
	help
fi

# Ensure the directory contains the Mozilla cert DB file key3.db.
if [ ! -f "${1}/key3.db" ]; then
	echo -e "\nError: File not found:  ${1}/key3.db"
	help
fi

# Ensure the directory contains the Mozilla cert DB file secmod.db.
if [ ! -f "${1}/secmod.db" ]; then
	echo -e "\nError: File not found:  ${1}/secmod.db"
	help
fi

# Assign the script argument to the variable certDB
certDB="$1"

# Loop through all the certs in the current folder that have the .cer extension
for cert in *.cer
do
 
  # echo "${nickName}"
  
  # Determine whether the cert is PEM or DER encoded
  file  ${cert} | grep data > /dev/null 2>&1
  results=$?
  if [ ${results} -eq 0 ]; then
	# DER Encoded cert
	Args=""
	inform=DER
  else
	# PEM encoded cert
	Args="-a"
	inform=PEM
  fi

  # Get a nickname based on the DN of the certificate.
  nickNametest=$(openssl x509 -inform ${inform} -subject -in ${cert} -noout)
  if [[ $nickNametest == *"/"* ]]; then
    odelim=/
  else
    odelim=,
  fi
  nickName="Raytheon $(openssl x509 -inform ${inform} -subject -in ${cert} -noout | awk -F ${odelim} '{for (i=NF;i>0;i--){printf $i"="}f "\n"}' | cut -f2,4 -d= | sed s/=/" - "/g | sed s/Raytheon/""/g)"

  # Set the CA trust based on the certificate name
  CA_Name="$(echo ${cert/.cer/} | cut -f1 -d_)"
  case "$CA_Name" in
	rtnroot)
		trust="CT,c,c"
		;;
	*)
		trust="CT,C,C"
		;;
  esac

  # install the certificate
#   echo "certutil -A -n \"${nickName}\"  -t \"${trust}\" ${Args} -d ${certDB} -i ${cert}"
  certutil -A -n "${nickName}"  -t "${trust}" ${Args} -d ${certDB} -i ${cert}
  result=$?

  # Report installation success or failure
  if [ ${result} -eq 0 ]; then
	echo -e "Successfully installed: ${cert} :\t ${nickName}"
  else
	echo -e "FAILED installation:    ${cert} :\t ${nickName}"
  fi
done

